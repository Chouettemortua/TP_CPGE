//
// Squelette TP 33
// Graphes eulériens et compilation séparée
//

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "stack.h"
#include "graph.h"

// Lecture de données depuis l'entrée standard
// Vous voyez dans le Makefile que le binaire euler.exe est appelé avec
// cat g3.txt | ./euler.exe
int *read_data(int *nb_vertex, int *nb_edges);

// Implémentation de l'algorithme de Hierholzer
// avec deux piles nommées euler et current
stack *euler_tour(graph g);

// Fonction main
int main(void){
    // Lit les data avec read_data(&nb_vertex, &nb_edges)
    // depuis l'entrée standard

    // puis construit un graph g avec build_graph(...)

    // enfin, construit la pile stack *tour avec euler_tour(g);

    // il faut l'afficher sur la sortie standard, dans le bon ordre

    return 0;
}
