(** Squelette programme quine.ml pour TP 37 sur l'algorithme de Quine
  * Jeudi 22 juin 2025
*)

(*****************************************)
(** Algorithme en force brute pour SAT. **)
(*****************************************)

(** Formules logiques *)
type formule =
  | C of bool
  | V of int
  | Et of formule * formule
  | Ou of formule * formule
  | Imp of formule * formule
  | Non of formule
;;

(** Taille d'une formule *)
let rec taille (f : formule) : int =
  failwith "TODO: écrire cette fonction !"
;;

(** Indice maximal d'une variable dans une formule *)
let rec var_max (f : formule) : int =
  failwith "TODO: écrire cette fonction !"
;;

(** Évaluation d'une formule *)
let rec evalue (f : formule) : int =
  failwith "TODO: écrire cette fonction !"
;;

(** Exception Derniere déclenchée par incremente_valuation *)
exception Derniere;;

type valuation = bool array;;

(** Prochaine valuation dans l'ordre de la numérotation par les entiers *)
let rec incremente_valuation (v : valuation) : unit =
  failwith "TODO: écrire cette fonction !"
;;

let satisfiable_brute (f : formule) : bool =
  failwith "TODO: écrire cette fonction !"
;;


(*************************)
(** Algorithme de Quine **)
(*************************)

(** Élimination des constantes *)
let rec elimine_constantes (f : formule) : formule =
  failwith "TODO: écrire cette fonction !"
;;

(** Substitution *)
let rec substitue (f : formule) (i : int) (g : formule) : formule =
  failwith "TODO: écrire cette fonction !"
;;

(** Trois variables. *)
let x0 : formule = V 0
and x1 : formule = V 1
and x2 : formule = V 2
;;

(** Et une formule. *)
let f : formule = Et(
  Imp(x0,
    Et(x1,
      Ou(Non x0, x2)
    )
  ),
  Non(Et(x0, x2))
);;

let g1 : formule = elimine_constantes (substitue f 0 (C true));;
let g2 : formule = elimine_constantes (substitue f 0 (C true));;

(** Un arbre de décision utilisé par l'algorithme de Quine. *)
type decision =
  | Feuille of bool
  | Noeud of int * decision * decision
;;

(** Construire l'arbre. *)
let rec construire_arbre (f : formule) : decision =
  failwith "TODO: écrire cette fonction !"
;;

(** Satisfiabilité d'une formule, décidée par son arbre de Quine. *)
let satisfiable_via_arbre (f : formule) : bool =
  failwith "TODO: écrire cette fonction !"
;;


(**************************************************************)
(** Un exemple d'application : le coloriage de graphes **)
(**************************************************************)

type graphe = int list array ;;

(* Graphe de Petersen : nombre chromatique égal à 3. *)
let petersen : graphe =
  [|
    [4; 5; 6];
    [6; 7; 8];
    [5; 8; 9];
    [4; 7; 9];
    [0; 3; 8];
    [0; 2; 7];
    [0; 1; 9];
    [1; 3; 5];
    [1; 2; 4];
    [2; 3; 6]
  |]
;;

(* Générateur de graphe aléatoire.
 * selon le modèle de Erdös-Renyi :
 * graphe_alea n p génère un graphe à n sommet
 * dans lequel chaque arête possible a une probabilité p
 * d'être choisie (indépendamment des autres). *)

let graphe_alea (n : int) (proba_arete : float) : graphe =
  let g = Array.make n [] in
  for i = 0 to n - 1 do
    for j = i + 1 to n - 1 do
      if Random.float 1. <= proba_arete then begin
        g.(i) <- j :: g.(i);
        g.(j) <- i :: g.(j)
      end
    done
  done;
  g
;;

(** Encodage du problème de la k-coloration de ce graphe dans une formule à SAT-isfaire. *)
let encode (g : graphe) (k : int) : formule =
  failwith "TODO: écrire cette fonction !"
;;

(** Est-ce que le graphe g est k-coloriable, en utilisant l'algorithme de Quine. *)
let est_k_coloriable (g : graphe) (k : int) : bool =
  failwith "TODO: écrire cette fonction !"
;;

(** Calcul du nombre chromatique de g, par la méthode que vous voulez (itérative exhaustive, dichotomie, etc). *)
let chromatique (g : graphe) : int =
  failwith "TODO: écrire cette fonction !"
;;


(** Lecture d'un graphe au format DIMACS. *)
let lire_dimacs (path : string) : graphe =
  failwith "TODO: écrire cette fonction !"
;;

(* chromatique (lire_dimacs "myciel3.col");; *)


(***************************)
(** Version plus efficace **)
(***************************)

let rec simplifie (i : int) (b : bool) (f : formule) : formule =
  failwith "TODO: écrire cette fonction !"
;;

let rec satisfiable (f : formule) : bool =
  failwith "TODO: écrire cette fonction !"
;;

(* chromatique (lire_dimacs "myciel4.col");; *)


(* chromatique (lire_dimacs "queen5_5.col");; *)
